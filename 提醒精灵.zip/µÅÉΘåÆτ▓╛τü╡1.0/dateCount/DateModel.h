//
//  DateModel.h
//  纪念日提醒
//
//  Created by zjsruxxxy3 on 14-11-1.
//  Copyright (c) 2014年 wrcj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DateModel : NSObject

@property(nonatomic,copy)NSString *dateText;

@property(nonatomic,copy)NSString *date;

@property(nonatomic,copy)NSString *identity;

@property(nonatomic,copy)NSString *fireDate;

@property(nonatomic,copy)NSString *access_token;

@end
