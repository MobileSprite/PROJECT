//
//  DateModel.m
//  纪念日提醒
//
//  Created by zjsruxxxy3 on 14-11-1.
//  Copyright (c) 2014年 wrcj. All rights reserved.
//

#import "DateModel.h"

@implementation DateModel

/*
-(id)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super init])
    {
        _dateText = [aDecoder decodeObjectForKey:@"dateText"];
        
        _date = [aDecoder decodeObjectForKey:@"date"];
        
        _identity = [aDecoder decodeObjectForKey:@"identity"];
        
        _fireDate = [aDecoder decodeObjectForKey:@"fireDate"];
        
    }
    
    return self;
    
}

-(void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self.dateText forKey:@"dateText"];
    
    [aCoder encodeObject:self.date forKey:@"date"];
    
    [aCoder encodeObject:self.identity forKey:@"identity"];
    
    [aCoder encodeObject:self.identity forKey:@"fireDate"];

}
 */

@end
