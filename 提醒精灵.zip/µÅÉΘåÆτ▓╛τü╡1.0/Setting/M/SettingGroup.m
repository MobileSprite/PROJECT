//
//  SettingGroup.m
//  SettingPro
//
//  Created by zjsruxxxy3 on 15/2/14.
//  Copyright (c) 2015年 wrcj. All rights reserved.
//

#import "SettingGroup.h"

@implementation SettingGroup

@end
