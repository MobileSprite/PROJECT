//
//  AppCommend.h
//  SettingPro
//
//  Created by zjsruxxxy3 on 15/2/15.
//  Copyright (c) 2015年 wrcj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppCommend : UIViewController

@end
