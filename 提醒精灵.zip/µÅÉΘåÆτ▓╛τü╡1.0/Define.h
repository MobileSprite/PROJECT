//
//  Define.h
//  提醒精灵1.0
//
//  Created by zjsruxxxy3 on 14-9-24.
//  Copyright (c) 2014年 wrcj. All rights reserved.
//

#ifndef ____1_0_Define_h
#define ____1_0_Define_h

#define PickerHeight [UIApplication sharedApplication].keyWindow.bounds.size.height<=480? 293:357
#define WinSize self.view.frame.size 
#define AnimateTimeGesture .45
#define AnimateTimePicker .45

#define theNoteNum 5

#define DateFormatter @"MM/dd HH:mm"

#define AimTime @"AimTimeArray"

#define theDate @"date"

#define theMusic @"music"

#define theText @"text"

#define theNew @"New"

#define theOnce @"once"

#define theIdenity @"idenity"

#define theTimesNum @"timesNum"

#define theNum @"num"

#define theMusicTime @"musicT"

#define theHandOff @"handOff"

#define RemaindIdenity @"ID"

#define theInfo @"groupInfo"

#define theUniqueID @"uniqueID"

#endif
