//
//  SwitchControllerTool.h
//  提醒精灵1.0
//
//  Created by zjsruxxxy3 on 15/2/12.
//  Copyright (c) 2015年 wrcj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SwitchControllerTool : NSObject


+(void)chooseRootViewController;

@end
