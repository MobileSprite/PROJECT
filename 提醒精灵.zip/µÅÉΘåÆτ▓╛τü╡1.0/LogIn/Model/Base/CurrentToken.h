//
//  CurrentToken.h
//  提醒精灵1.0
//
//  Created by zjsruxxxy3 on 15/2/13.
//  Copyright (c) 2015年 wrcj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CurrentToken : NSObject<NSCoding>

@property(nonatomic,copy)NSString *current_access_token;

@end
